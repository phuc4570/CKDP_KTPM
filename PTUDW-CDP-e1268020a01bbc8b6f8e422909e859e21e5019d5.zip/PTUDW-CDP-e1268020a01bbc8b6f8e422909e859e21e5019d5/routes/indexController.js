exports.auth = (req, res)=>{
    res.redirect("/auth");
}