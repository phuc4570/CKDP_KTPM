exports.register = (req, res) => {
  res.render("admin/register/register", { layout: "admin_layout" });
};
