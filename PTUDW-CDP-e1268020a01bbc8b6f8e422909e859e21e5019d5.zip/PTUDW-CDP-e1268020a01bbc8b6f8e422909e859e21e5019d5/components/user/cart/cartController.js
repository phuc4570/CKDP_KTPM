exports.cart = (req, res) => {
  res.render("user/cart/cart", { layout: "user_layout" });
};
