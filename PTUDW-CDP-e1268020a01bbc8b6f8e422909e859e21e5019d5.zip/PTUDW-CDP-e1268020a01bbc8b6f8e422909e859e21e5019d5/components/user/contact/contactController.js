exports.contact = (req, res) => {
  res.render("user/contact/contact", { layout: "user_layout" });
};
