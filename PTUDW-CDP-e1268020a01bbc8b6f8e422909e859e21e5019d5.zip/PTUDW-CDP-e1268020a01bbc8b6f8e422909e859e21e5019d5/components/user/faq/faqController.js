exports.faq = (req, res) => {
  res.render("user/faq/faq", { layout: "user_layout" });
};
